#!/bin/bash
valid=1

while [ "$valid" -ge 1 ];
do
   echo Please enter your activation key.
   read activkey
   if [ "$activkey" == "" ]; then
       echo aborting
       exit 0
   fi
   outkey=`./validatekey $activkey`
   valid=$?
done
echo -n $outkey > activkey
echo "Your license key will be activated. Press enter to continue"
read blah
java -cp SageTVActivationClient.jar tv.sage.util.SageTVActivationClient activkey . key
